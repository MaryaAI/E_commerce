<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">عرض تفاصيل الكتاب</div>

                <div class="card-body">
                    <table class="table table-stribed">
                        <tr>
                            <th>العنوان</th>
                            <td class="lead"><b><?php echo e($book->title); ?></b></td>
                        </tr>
                        <tr>
                            <th>تقييم المستخدمين</th>
                            <td>
                                <span class="score">
                                    <div class="score-wrap">
                                        <span class="stars-active" style="width:<?php echo e($book->rate()*20); ?>%">
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                        </span>
                                        
                                        <span class="stars-inactive">
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                        </span>
                                    </div>
                                </span>

                                <span>عدد المقيّمين <?php echo e($book->ratings()->count()); ?> مستخدم</span>

                            </td>
                        </tr>
                        <?php if($book->isbn): ?>
                            <tr>
                                <th>الرقم التسلسلي</th>
                                <td><?php echo e($book->isbn); ?></td>
                            </tr>
                        <?php endif; ?>
                        <tr>
                            <th>صورة الغلاف</th>
                            <td><img class="img-fluid img-thumbnail" src="<?php echo e(asset('storage/' . $book->cover_image)); ?>"></td>
                        </tr>
                        <?php if($book->category): ?>
                            <tr>
                                <th>التصنيف</th>
                                <td><?php echo e($book->category->name); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php if($book->authors()->count() > 0): ?>
                            <tr>
                                <th>المؤلفون</th>
                                <td>
                                    <?php $__currentLoopData = $book->authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($loop->first ? '' : 'و'); ?>

                                        <?php echo e($author->name); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php if($book->publisher): ?>
                            <tr>
                                <th>الناشر</th>
                                <td><?php echo e($book->publisher->name); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php if($book->description): ?>
                            <tr>
                                <th>الوصف</th>
                                <td><?php echo e($book->description); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php if($book->publish_year): ?>
                            <tr>
                                <th>سنة النشر</th>
                                <td><?php echo e($book->publish_year); ?></td>
                            </tr>
                        <?php endif; ?>
                        <tr>
                            <th>عدد الصفحات</th>
                            <td><?php echo e($book->number_of_pages); ?></td>
                        </tr>
                        <tr>
                            <th>عدد النسخ</th>
                            <td><?php echo e($book->number_of_copies); ?></td>
                        </tr>
                        <tr>
                            <th>السعر</th>
                            <td><?php echo e($book->price); ?> $</td>
                        </tr>

                    </table>

                    <?php if(auth()->guard()->check()): ?>
                        <h4>قيّم هذا الكتاب<h4>

                        <?php if(auth()->user()->rated($book)): ?>
                            <div class="rating">
                                <span class="rating-star <?php echo e(auth()->user()->bookRating($book)->value == 5 ? 'checked' : ''); ?>" data-value="5"></span>
                                <span class="rating-star <?php echo e(auth()->user()->bookRating($book)->value == 4 ? 'checked' : ''); ?>" data-value="4"></span>
                                <span class="rating-star <?php echo e(auth()->user()->bookRating($book)->value == 3 ? 'checked' : ''); ?>" data-value="3"></span>
                                <span class="rating-star <?php echo e(auth()->user()->bookRating($book)->value == 2 ? 'checked' : ''); ?>" data-value="2"></span>
                                <span class="rating-star <?php echo e(auth()->user()->bookRating($book)->value == 1 ? 'checked' : ''); ?>" data-value="1"></span>
                            </div>
                        <?php else: ?>
                            <div class="rating">
                                <span class="rating-star" data-value="5"></span>
                                <span class="rating-star" data-value="4"></span>
                                <span class="rating-star" data-value="3"></span>
                                <span class="rating-star" data-value="2"></span>
                                <span class="rating-star" data-value="1"></span>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>        
        $('.rating-star').click(function() {
            $(this).parents('.rating').find('.rating-star').removeClass('checked');
            $(this).addClass('checked');
                
            var submitStars = $(this).attr('data-value');
            
            $.ajax({
                type: 'post',
                url: <?php echo e($book->id); ?> + '/rate',
                data: {
                    '_token': $('meta[name="csrf-token"]').attr('content'),
                    'value' : submitStars
                },
                success: function() {
                    alert('تمت عملية التقييم بنجاح');
                    location.reload();
                },
                error: function() {
                    alert('حدث خطأ ما');
                },
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookshop\resources\views/books/details.blade.php ENDPATH**/ ?>