<?php $__env->startSection('heading'); ?>
عرض كتاب
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-2"></div>
    
    <div class="card mb-4 col-md-8">
        <div class="card-header text-right">
            عرض بيانات الكتاب
        </div>
        <div class="card-body">
            <table class="table table-stribed">
                <tr>
                    <th>العنوان</th>
                    <td class="lead"><b><?php echo e($book->title); ?></b></td>
                </tr>
                <?php if($book->isbn): ?>
                    <tr>
                        <th>الرقم التسلسلي</th>
                        <td><?php echo e($book->isbn); ?></td>
                    </tr>
                <?php endif; ?>
                <tr>
                    <th>صورة الغلاف</th>
                    <td><img class="img-fluid img-thumbnail" src="<?php echo e(asset('storage/' . $book->cover_image)); ?>"></td>
                </tr>
                <?php if($book->category): ?>
                    <tr>
                        <th>التصنيف</th>
                        <td><?php echo e($book->category->name); ?></td>
                    </tr>
                <?php endif; ?>
                <?php if($book->authors()->count() > 0): ?>
                    <tr>
                        <th>المؤلفون</th>
                        <td>
                            <?php $__currentLoopData = $book->authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($loop->first ? '' : 'و'); ?>

                                <?php echo e($author->name); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                <?php endif; ?>
                <?php if($book->publisher): ?>
                    <tr>
                        <th>الناشر</th>
                        <td><?php echo e($book->publisher->name); ?></td>
                    </tr>
                <?php endif; ?>
                <?php if($book->description): ?>
                    <tr>
                        <th>الوصف</th>
                        <td><?php echo e($book->description); ?></td>
                    </tr>
                <?php endif; ?>
                <?php if($book->publish_year): ?>
                    <tr>
                        <th>سنة النشر</th>
                        <td><?php echo e($book->publish_year); ?></td>
                    </tr>
                <?php endif; ?>
                <tr>
                    <th>عدد الصفحات</th>
                    <td><?php echo e($book->number_of_pages); ?></td>
                </tr>
                <tr>
                    <th>عدد النسخ</th>
                    <td><?php echo e($book->number_of_copies); ?></td>
                </tr>
                <tr>
                    <th>السعر</th>
                    <td><?php echo e($book->price); ?> $</td>
                </tr>

            </table>
            <a class="btn btn-primary btn-sm" href="<?php echo e(route('books.edit', $book)); ?>"><i class="fa fa-edit"></i> تعديل</a>
            <form method="POST" action="<?php echo e(route('books.show', $book)); ?>" style="display:inline-block">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('هل أنت متأكد؟')"><i class="fa fa-trash"></i> حذف</button> 
            </form>
        </div>
    </div>

    <div class="col-md-2"></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookshop\resources\views/admin/books/show.blade.php ENDPATH**/ ?>