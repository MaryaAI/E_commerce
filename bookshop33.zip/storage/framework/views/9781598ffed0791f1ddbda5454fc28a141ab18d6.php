<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">عربة التسوق</div>

                <div class="card-body">
                    
                    <?php if($items->count()): ?>

                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">العنوان</th>
                                <th scope="col">السعر</th>
                                <th scope="col">الكمية</th>
                                <th scope="col">السعر الكلي</th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <?php ($totalPrice = 0); ?>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php ($totalPrice += $item->price * $item->pivot->number_of_copies); ?>

                            <tbody>
                                <tr>
                                    <th scope="row"><?php echo e($item->title); ?></th>
                                    <td><?php echo e($item->price); ?> $</td>
                                    <td><?php echo e($item->pivot->number_of_copies); ?></td>
                                    <td><?php echo e($item->price * $item->pivot->number_of_copies); ?> $</td>
                                    <td>
                                        <form style="float:left; margin: auto 5px" method="post" action="<?php echo e(route('cart.remove_all', $item->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-danger btn-sm" type="submit">أزل الكل</button>
                                        </form>

                                        <form style="float:left; margin: auto 5px" method="post" action="<?php echo e(route('cart.remove_one', $item->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-warning btn-sm" type="submit">أزل واحدًا</button>
                                        </form>
                                    </td>
                                </tr>
                            </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>

                    <h4>المجموع النهائي: <?php echo e($totalPrice); ?> $</h4>
                    
                    <?php else: ?>

                    <h1>لا يوجد كتب في العربة</h1>
                    
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookshop\resources\views/cart.blade.php ENDPATH**/ ?>