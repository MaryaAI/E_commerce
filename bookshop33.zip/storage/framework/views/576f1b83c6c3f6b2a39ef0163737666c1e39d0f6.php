<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">معرض الكتب</div>

                <div class="card-body">
                    
                    <div class="row">
                        <div class="col-md-4"></div>

                        <form class="form-inline col-md-6" action="<?php echo e(route('search')); ?>" method="GET">
                            <input type="text" class="form-control mx-sm-3 mb-2" name="term" value="<?php echo e($_GET['term'] ?? ''); ?>">
                            <button type="submit" class="btn btn-secondary mb-2">ابحث</button>
                        </form>

                        <div class="col-md-2"></div>
                    </div>
                    <hr>
                    <br>
                    <h3><?php echo e($title); ?></h3>
                    <br><br>
                    <div class="row">
                        <?php if($books->count()): ?>
                            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($book->number_of_copies > 0): ?>
                                    <div class="col-lg-3 col-md-4 col-6" style="margin-bottom:10px">
                                        <div class="d-block mb-4 h-100 border rounded" style="padding:10px">
                                            <a href="<?php echo e(route('book.details', $book)); ?>" style="color:#555555">
                                                <img class="img-fluid img-thumbnail" src="<?php echo e(asset('storage/' . $book->cover_image)); ?>" alt="">
                                                
                                                <b><?php echo e($book->title); ?></b>
                                            </a>

                                            <span class="score">
                                                <div class="score-wrap">
                                                    <span class="stars-active" style="width:<?php echo e($book->rate()*20); ?>%">
                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                    </span>
                                                    
                                                    <span class="stars-inactive">
                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                    </span>
                                                </div>
                                            </span>
                                            
                                            <?php if($book->category != NULL): ?>
                                                <br><a style="color:#525252" href="#"><?php echo e($book->category->name); ?></a>
                                            <?php endif; ?>

                                            <?php if($book->authors->isNotEmpty()): ?>
                                                <br><b>تأليف: </b>
                                                <?php $__currentLoopData = $book->authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($loop->first ? '' : 'و'); ?>

                                                    <a style="color:#525252" href="#"><?php echo e($author->name); ?> </a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>

                                            <br><b>السعر: </b><?php echo e($book->price); ?> $

                                            <?php if(auth()->guard()->check()): ?>
                                                <form method="POST" action="<?php echo e(route('cart.add')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <input name="id" type="hidden" value="<?php echo e($book->id); ?>">
                                                    <input class="form-control" name="quantity" type="number" value="1" min="1" max="<?php echo e($book->number_of_copies); ?>" style="width:40%; float:right" required>
                                                    <button type="submit" class="btn btn-primary" style="margin-right: 10px"> أضف <i class="fas fa-cart-plus"></i></button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <div class="col-12"><?php echo e($books->links()); ?></div>
                            
                        <?php else: ?>
                            <h3 style="margin:0 auto">لا نتائج</h3>
                        <?php endif; ?>
                    </div>        
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookshop\resources\views/gallery.blade.php ENDPATH**/ ?>